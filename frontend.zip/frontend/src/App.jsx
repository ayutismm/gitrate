import { useState } from 'react';
import { rateDeveloper } from './services/api';
import SearchBar from './components/SearchBar';
import Dashboard from './components/Dashboard';
import AnalysisCards from './components/AnalysisCards';
import LoadingState from './components/LoadingState';

function App() {
  const [result, setResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);

  const loadingSteps = [
    "Connecting...",
    "Fetching data...",
    "Analyzing...",
    "Calculating...",
    "Finalizing..."
  ];

  const handleSearch = async (username) => {
    const cleanUsername = username.replace(/^@/, '');
    setIsLoading(true);
    setError(null);
    setResult(null);
    setCurrentStep(0);

    const interval = setInterval(() => {
      setCurrentStep(prev => {
        if (prev < loadingSteps.length - 1) return prev + 1;
        return prev;
      });
    }, 800);

    try {
      const data = await rateDeveloper(cleanUsername);
      setResult(data);
    } catch (err) {
      setError(err.message || 'Failed to analyze user');
    } finally {
      clearInterval(interval);
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center py-20 px-4">

      {/* Header */}
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-3xl font-bold tracking-tight text-white">
          GitRate
        </h1>
        <p className="text-zinc-500 text-sm max-w-md mx-auto">
          AI-powered profile analysis focusing on fairness, quality, and impact.
        </p>
      </div>

      {/* Search */}
      <div className="w-full mb-12 flex justify-center">
        <SearchBar onSearch={handleSearch} isLoading={isLoading} />
      </div>

      {/* Content */}
      <div className="w-full max-w-4xl">
        {error && (
          <div className="w-full max-w-md mx-auto bg-red-950/30 border border-red-900/50 text-red-400 p-4 rounded text-sm text-center mb-8">
            <p className="font-medium">Analysis Failed</p>
            <p className="opacity-80">{error}</p>
          </div>
        )}

        {isLoading && (
          <LoadingState steps={loadingSteps} currentStep={currentStep} />
        )}

        {/* Recent Searches / Suggestions - REMOVED */}

        {result && !isLoading && !error && (
          <div>
            <Dashboard data={result} />
            <AnalysisCards analysis={result.detailed_analysis} />

            <div className="mt-12 pt-8 border-t border-zinc-900 text-center text-zinc-600 text-xs">
              <p>GitHub Developer Rating Engine</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
