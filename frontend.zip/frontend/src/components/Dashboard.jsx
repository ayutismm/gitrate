
export default function Dashboard({ data }) {

    const scores = [
        { label: 'Contribution', value: data.contribution_score },
        { label: 'PR Quality', value: data.pr_quality_score },
        { label: 'Impact', value: data.impact_score },
        { label: 'Code Quality', value: data.code_quality_score },
    ];

    return (
        <div className="w-full max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">

            {/* Header Section */}
            <div className="minimal-card p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="text-center md:text-left">
                    <h2 className="text-zinc-400 text-xs uppercase tracking-widest mb-2">Total Score</h2>
                    <div className="text-6xl font-bold tracking-tighter text-white">
                        {Math.round(data.final_score)}
                    </div>
                    <div className="text-sm text-zinc-500 mt-1">
                        Tier: <span className="text-white font-medium">{data.tier}</span>
                    </div>
                </div>

                <div className="w-full md:w-1/2 space-y-3">
                    {scores.map((score) => (
                        <div key={score.label} className="space-y-1">
                            <div className="flex justify-between text-xs">
                                <span className="text-zinc-400">{score.label}</span>
                                <span className="text-zinc-300 font-mono">{Math.round(score.value)}</span>
                            </div>
                            <div className="h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden">
                                <div
                                    className="h-full bg-white rounded-full"
                                    style={{ width: `${score.value}%` }}
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Analysis Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="minimal-card p-6">
                    <h3 className="text-sm font-semibold text-white mb-4 border-b border-zinc-800 pb-2">Strengths</h3>
                    <ul className="space-y-2">
                        {data.strengths.map((str, i) => (
                            <li key={i} className="text-sm text-zinc-400 flex gap-2">
                                <span className="text-white">+</span> {str}
                            </li>
                        ))}
                    </ul>
                </div>

                <div className="minimal-card p-6">
                    <h3 className="text-sm font-semibold text-white mb-4 border-b border-zinc-800 pb-2">Improvements</h3>
                    <ul className="space-y-2">
                        {data.weaknesses.map((weak, i) => (
                            <li key={i} className="text-sm text-zinc-400 flex gap-2">
                                <span className="text-zinc-600">-</span> {weak}
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

            {/* Summary */}
            <div className="minimal-card p-6">
                <h3 className="text-sm font-semibold text-white mb-2">Summary</h3>
                <p className="text-sm text-zinc-400 leading-relaxed">
                    {data.summary}
                </p>
            </div>
        </div>
    );
}
