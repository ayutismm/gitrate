export default function RadarChart({ scores }) {
    // Scores: contribution, pr_quality, impact, code_quality
    const labels = ['Contribution', 'PR Quality', 'Impact', 'Code Quality'];
    const values = [
        scores.contribution_score || 0,
        scores.pr_quality_score || 0,
        scores.impact_score || 0,
        scores.code_quality_score || 0,
    ];

    // SVG dimensions
    const size = 300;
    const center = size / 2;
    const maxRadius = 120;

    // Calculate points for polygon
    const angleStep = (2 * Math.PI) / 4;
    const startAngle = -Math.PI / 2; // Start from top

    const getPoint = (value, index) => {
        const angle = startAngle + index * angleStep;
        const radius = (value / 100) * maxRadius;
        return {
            x: center + radius * Math.cos(angle),
            y: center + radius * Math.sin(angle),
        };
    };

    const getLabelPoint = (index) => {
        const angle = startAngle + index * angleStep;
        const radius = maxRadius + 30;
        return {
            x: center + radius * Math.cos(angle),
            y: center + radius * Math.sin(angle),
        };
    };

    // Create polygon points
    const points = values.map((v, i) => getPoint(v, i));
    const polygonPoints = points.map((p) => `${p.x},${p.y}`).join(' ');

    // Grid circles
    const gridCircles = [25, 50, 75, 100];

    return (
        <div className="flex flex-col items-center">
            <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
                {/* Grid circles */}
                {gridCircles.map((percent) => (
                    <circle
                        key={percent}
                        cx={center}
                        cy={center}
                        r={(percent / 100) * maxRadius}
                        fill="none"
                        stroke="rgba(255,255,255,0.1)"
                        strokeWidth="1"
                    />
                ))}

                {/* Axis lines */}
                {[0, 1, 2, 3].map((i) => {
                    const endPoint = getPoint(100, i);
                    return (
                        <line
                            key={i}
                            x1={center}
                            y1={center}
                            x2={endPoint.x}
                            y2={endPoint.y}
                            stroke="rgba(255,255,255,0.1)"
                            strokeWidth="1"
                        />
                    );
                })}

                {/* Data polygon */}
                <polygon
                    points={polygonPoints}
                    fill="rgba(99, 102, 241, 0.3)"
                    stroke="url(#radarGradient)"
                    strokeWidth="2"
                />

                {/* Gradient definition */}
                <defs>
                    <linearGradient id="radarGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#6366f1" />
                        <stop offset="50%" stopColor="#a855f7" />
                        <stop offset="100%" stopColor="#ec4899" />
                    </linearGradient>
                </defs>

                {/* Data points */}
                {points.map((point, i) => (
                    <circle
                        key={i}
                        cx={point.x}
                        cy={point.y}
                        r="6"
                        fill="url(#radarGradient)"
                        stroke="#fff"
                        strokeWidth="2"
                    />
                ))}

                {/* Labels */}
                {labels.map((label, i) => {
                    const labelPoint = getLabelPoint(i);
                    return (
                        <text
                            key={i}
                            x={labelPoint.x}
                            y={labelPoint.y}
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fill="rgba(255,255,255,0.7)"
                            fontSize="12"
                            fontWeight="500"
                        >
                            {label}
                        </text>
                    );
                })}

                {/* Score values */}
                {values.map((value, i) => {
                    const point = getPoint(value, i);
                    return (
                        <text
                            key={`value-${i}`}
                            x={point.x}
                            y={point.y - 15}
                            textAnchor="middle"
                            fill="#fff"
                            fontSize="11"
                            fontWeight="600"
                        >
                            {Math.round(value)}
                        </text>
                    );
                })}
            </svg>
        </div>
    );
}
