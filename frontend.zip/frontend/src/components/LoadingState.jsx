export default function LoadingState({ steps, currentStep }) {
    return (
        <div className="w-full max-w-lg mx-auto p-8 border border-zinc-800 rounded-lg bg-zinc-900/50">
            <div className="flex flex-col items-center gap-4">
                <div className="w-6 h-6 border-2 border-zinc-700 border-t-white rounded-full animate-spin" />
                <div className="space-y-1 text-center">
                    <p className="text-sm font-medium text-white">
                        {steps[currentStep] || 'Processing...'}
                    </p>
                    <div className="w-48 h-1 bg-zinc-800 rounded-full mx-auto overflow-hidden">
                        <div
                            className="h-full bg-white transition-all duration-300 ease-out"
                            style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}
