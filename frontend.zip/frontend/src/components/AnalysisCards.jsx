export default function AnalysisCards({ analysis }) {
    const items = [
        { title: 'Contribution', content: analysis.contribution_analysis },
        { title: 'PR Quality', content: analysis.pr_analysis },
        { title: 'Impact', content: analysis.impact_analysis },
        { title: 'Code Quality', content: analysis.code_quality_analysis },
    ];

    return (
        <div className="w-full max-w-4xl mx-auto mt-8 mb-20">
            <h3 className="text-sm font-semibold text-zinc-500 mb-4 uppercase tracking-wider">Detailed Report</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {items.map((item) => (
                    <div key={item.title} className="minimal-card p-6 hover:border-zinc-600 transition-colors">
                        <h4 className="text-white font-medium mb-2">{item.title}</h4>
                        <p className="text-sm text-zinc-400 leading-relaxed">
                            {item.content}
                        </p>
                    </div>
                ))}
            </div>
        </div>
    );
}
