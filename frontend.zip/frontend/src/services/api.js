const API_BASE_URL = 'http://localhost:8000';

export async function rateDeveloper(username) {
    const response = await fetch(`${API_BASE_URL}/api/rate/${encodeURIComponent(username)}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
    });

    if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
        throw new Error(error.detail || `Failed to rate user: ${response.status}`);
    }

    return response.json();
}

export async function getUserData(username) {
    const response = await fetch(`${API_BASE_URL}/api/user/${encodeURIComponent(username)}/data`);

    if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
        throw new Error(error.detail || `Failed to get user data: ${response.status}`);
    }

    return response.json();
}

export async function healthCheck() {
    const response = await fetch(`${API_BASE_URL}/api/health`);
    return response.ok;
}
